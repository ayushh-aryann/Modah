import React, { useState } from 'react';
import { Menu, Search, User2, HelpCircle, ShoppingBag, X } from 'lucide-react';
import Hero from './components/Hero';
import ProductGrid from './components/ProductGrid';
import Cart from './components/Cart';
import Newsletter from './components/Newsletter';
import ProductDetails from './components/ProductDetails';
import WomenSection from './components/WomenSection';
import NewArrivals from './components/NewArrivals';
import MensNewArrivals from './components/MensNewArrivals';
import NewArrivalsPage from './components/NewArrivalsPage';
import Chatbot from './components/Chatbot';

function App() {
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showProducts, setShowProducts] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [cartItems, setCartItems] = useState([]);

  const handleNavigation = (section) => {
    setActiveSection(section);
    setShowProducts(false);
  };

  const addToCart = (product, quantity = 1) => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(item => 
        item.id === product.id && item.selectedSize === product.selectedSize
      );

      if (existingItem) {
        return prevItems.map(item =>
          item.id === product.id && item.selectedSize === product.selectedSize
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }

      return [...prevItems, { ...product, quantity }];
    });
    setIsCartOpen(true);
  };

  const updateQuantity = (productId, newQuantity) => {
    if (newQuantity < 1) {
      removeFromCart(productId);
      return;
    }

    setCartItems(prevItems =>
      prevItems.map(item =>
        item.id === productId
          ? { ...item, quantity: newQuantity }
          : item
      )
    );
  };

  const removeFromCart = (productId) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== productId));
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Mobile menu */}
      <div className={`fixed inset-0 bg-black bg-opacity-50 z-50 lg:hidden transition-opacity ${
        isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
      }`}>
        <div className={`fixed inset-y-0 left-0 w-64 bg-white transform transition-transform ${
          isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}>
          <div className="p-6">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-xl font-didot">MODAH</h2>
              <button 
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X size={24} />
              </button>
            </div>
            
            <div className="space-y-4">
              <button 
                onClick={() => {
                  handleNavigation('men');
                  setIsMobileMenuOpen(false);
                }} 
                className="block text-lg font-medium text-gray-900 hover:text-gray-600 interactive-button"
              >
                MEN
              </button>
              <button 
                onClick={() => {
                  handleNavigation('women');
                  setIsMobileMenuOpen(false);
                }} 
                className="block text-lg font-medium text-gray-900 hover:text-gray-600 interactive-button"
              >
                WOMEN
              </button>
              <button 
                onClick={() => {
                  handleNavigation('jackets');
                  setIsMobileMenuOpen(false);
                }} 
                className="block text-lg font-medium text-gray-900 hover:text-gray-600 interactive-button"
              >
                JACKETS
              </button>
              <button 
                onClick={() => {
                  handleNavigation('new-arrivals');
                  setIsMobileMenuOpen(false);
                }} 
                className="block text-lg font-medium text-gray-900 hover:text-gray-600 interactive-button"
              >
                NEW ARRIVALS
              </button>
              <button 
                onClick={() => {
                  handleNavigation('mens-new-arrivals');
                  setIsMobileMenuOpen(false);
                }} 
                className="block text-lg font-medium text-gray-900 hover:text-gray-600 interactive-button"
              >
                MEN'S NEW ARRIVALS
              </button>
              <button 
                onClick={() => {
                  handleNavigation('new-arrivals-carousel');
                  setIsMobileMenuOpen(false);
                }} 
                className="block text-lg font-medium text-gray-900 hover:text-gray-600 interactive-button"
              >
                NEW ARRIVALS CAROUSEL
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="fixed top-0 w-full bg-white z-40 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <button 
                className="text-gray-800 lg:hidden rounded-full hover:bg-gray-100 p-2"
                onClick={() => setIsMobileMenuOpen(true)}
              >
                <Menu size={24} />
              </button>
              <h1 className="ml-4 lg:ml-0 text-2xl font-didot tracking-wider">MODAH</h1>
            </div>
            
            <nav className="hidden lg:flex space-x-8">
              <button 
                onClick={() => handleNavigation('men')} 
                className="font-bd-sans text-gray-800 hover:text-gray-600 interactive-button"
              >
                MEN
              </button>
              <button 
                onClick={() => handleNavigation('women')} 
                className="font-bd-sans text-gray-800 hover:text-gray-600 interactive-button"
              >
                WOMEN
              </button>
              <button 
                onClick={() => handleNavigation('jackets')} 
                className="font-bd-sans text-gray-800 hover:text-gray-600 interactive-button"
              >
                JACKETS
              </button>
              <button 
                onClick={() => handleNavigation('new-arrivals')} 
                className="font-bd-sans text-gray-800 hover:text-gray-600 interactive-button"
              >
                NEW ARRIVALS
              </button>
              <button 
                onClick={() => handleNavigation('mens-new-arrivals')} 
                className="font-bd-sans text-gray-800 hover:text-gray-600 interactive-button"
              >
                MEN'S NEW
              </button>
              <button 
                onClick={() => handleNavigation('new-arrivals-carousel')} 
                className="font-bd-sans text-gray-800 hover:text-gray-600 interactive-button"
              >
                CAROUSEL
              </button>
            </nav>

            <div className="flex items-center space-x-6">
              <div className="relative">
                <button 
                  onClick={() => setShowSearch(!showSearch)}
                  className="text-gray-800 hover:text-gray-600 rounded-full hover:bg-gray-100 p-2"
                >
                  <Search size={20} />
                </button>
                {showSearch && (
                  <div className="absolute right-0 mt-2 w-64 bg-white shadow-lg rounded-lg p-4">
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search products..."
                      className="search-input"
                    />
                  </div>
                )}
              </div>
              <button className="text-gray-800 hover:text-gray-600 rounded-full hover:bg-gray-100 p-2">
                <User2 size={20} />
              </button>
              <button className="text-gray-800 hover:text-gray-600 rounded-full hover:bg-gray-100 p-2">
                <HelpCircle size={20} />
              </button>
              <button 
                className="text-gray-800 hover:text-gray-600 rounded-full hover:bg-gray-100 p-2 relative"
                onClick={() => setIsCartOpen(true)}
              >
                <ShoppingBag size={20} />
                <span className="absolute -top-1 -right-1 bg-black text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  {cartItems.reduce((sum, item) => sum + item.quantity, 0)}
                </span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="pt-16">
        {selectedProduct ? (
          <ProductDetails 
            product={selectedProduct} 
            onClose={() => setSelectedProduct(null)}
            onAddToCart={addToCart}
          />
        ) : (
          <>
            {activeSection === 'home' && !showProducts && <Hero onStartShopping={() => setShowProducts(true)} />}
            {activeSection === 'women' && <WomenSection onProductClick={setSelectedProduct} />}
            {activeSection === 'new-arrivals' && <NewArrivals onProductClick={setSelectedProduct} />}
            {activeSection === 'mens-new-arrivals' && <MensNewArrivals onProductClick={setSelectedProduct} />}
            {activeSection === 'new-arrivals-carousel' && <NewArrivalsPage onProductClick={setSelectedProduct} />}
            {(showProducts || activeSection === 'jackets' || activeSection === 'men') && 
              <ProductGrid 
                onProductClick={setSelectedProduct} 
                initialCategory={activeSection === 'jackets' ? 'jackets' : activeSection === 'men' ? 'men' : 'all'} 
              />
            }
            <Newsletter />
          </>
        )}
      </main>

      <Cart 
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={updateQuantity}
        onRemoveItem={removeFromCart}
      />

      <Chatbot />

      {/* About Us Section */}
      <section className="bg-white py-16">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-didot mb-8 text-center">About Us</h2>
          <div className="space-y-6 text-gray-600">
            <p>
              At Modah, fashion is more than just clothing—it's a statement of style, confidence, and individuality. We curate the latest trends with premium quality fabrics, contemporary designs, and timeless elegance to elevate your wardrobe.
            </p>
            <p>
              Our mission is to offer a seamless shopping experience with a handpicked selection of apparel and accessories that cater to modern fashion enthusiasts. Whether it's chic bottomwear, classic shirts, trendy T-shirts, or must-have accessories, we ensure that every piece reflects sophistication and comfort.
            </p>
            <p>
              With secure payments, hassle-free returns, and dedicated customer support, we make online shopping effortless. Stay ahead of trends with Modah—where fashion meets elegance.
            </p>
            <p className="font-bd-sans text-black">
              Join us and redefine your style!
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase">BRAND</h3>
              <ul className="mt-4 space-y-4">
                <li><a href="#" className="text-gray-600 hover:text-gray-800">About Us</a></li>
                <li><a href="#" className="text-gray-600 hover:text-gray-800">Careers</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase">SUPPORT</h3>
              <ul className="mt-4 space-y-4">
                <li><a href="#" className="text-gray-600 hover:text-gray-800">Contact</a></li>
                <li><a href="#" className="text-gray-600 hover:text-gray-800">FAQ</a></li>
                <li><a href="#" className="text-gray-600 hover:text-gray-800">Returns</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase">LEGAL</h3>
              <ul className="mt-4 space-y-4">
                <li><a href="#" className="text-gray-600 hover:text-gray-800">Privacy Policy</a></li>
                <li><a href="#" className="text-gray-600 hover:text-gray-800">Terms of Service</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase">JOIN THE CULT</h3>
              <p className="mt-4 text-gray-600">Sign up to our newsletter for 10% off your first order.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;