import React, { useState } from 'react';
import { X } from 'lucide-react';

export default function Cart({ isOpen, onClose, items, onUpdateQuantity, onRemoveItem }) {
  const [couponCode, setCouponCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState(null);

  const subtotal = items.reduce((sum, item) => {
    const price = parseFloat(item.price.replace('₹', '').replace(',', ''));
    return sum + price * item.quantity;
  }, 0);

  const discount = appliedDiscount ? (subtotal * appliedDiscount.percentage) / 100 : 0;
  const total = subtotal - discount;

  const handleApplyCoupon = () => {
    const coupons = {
      'WELCOME10': { code: 'WELCOME10', percentage: 10 },
      'SUMMER20': { code: 'SUMMER20', percentage: 20 }
    };

    if (coupons[couponCode]) {
      setAppliedDiscount(coupons[couponCode]);
    } else {
      alert('Invalid coupon code');
    }
  };

  return (
    <div className={`fixed inset-0 bg-black bg-opacity-50 z-50 transition-opacity ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
      <div className={`fixed inset-y-0 right-0 w-full max-w-md bg-white transform transition-transform ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="h-full flex flex-col">
          <div className="px-6 py-4 border-b">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-medium">Shopping Cart</h2>
              <button onClick={onClose}>
                <X size={24} />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto px-6 py-4">
            {items.length === 0 ? (
              <p className="text-center text-gray-500">Your cart is empty</p>
            ) : (
              <div className="space-y-6">
                {items.map((item) => (
                  <div key={item.id} className="cart-item">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="cart-item-image"
                    />
                    <div className="flex-1">
                      <h3 className="text-sm font-medium">{item.name}</h3>
                      <p className="text-sm text-gray-500">Size: {item.selectedSize}</p>
                      <p className="text-sm font-medium">{item.price}</p>
                      <div className="flex items-center space-x-2 mt-2">
                        <button
                          className="cart-quantity-button"
                          onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                        >
                          -
                        </button>
                        <span className="w-8 text-center">{item.quantity}</span>
                        <button
                          className="cart-quantity-button"
                          onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                        >
                          +
                        </button>
                      </div>
                    </div>
                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <X size={20} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {items.length > 0 && (
            <div className="border-t px-6 py-4 space-y-4">
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                  placeholder="Enter coupon code"
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg"
                />
                <button
                  onClick={handleApplyCoupon}
                  className="interactive-button bg-black text-white hover:bg-gray-900"
                >
                  Apply
                </button>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>₹{subtotal.toFixed(2)}</span>
                </div>
                {appliedDiscount && (
                  <div className="flex justify-between text-green-600">
                    <span>Discount ({appliedDiscount.percentage}%)</span>
                    <span>-₹{discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-medium text-lg">
                  <span>Total</span>
                  <span>₹{total.toFixed(2)}</span>
                </div>
              </div>

              <button className="w-full bg-black text-white py-3 hover:bg-gray-900 rounded-lg shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 ease-in-out">
                Checkout
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}