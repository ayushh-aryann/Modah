import React from 'react';

const womenProducts = [
  {
    id: 'wf1',
    name: 'Faux Fur Coat',
    price: '₹18,900',
    image: 'https://images.unsplash.com/photo-1548624149-f9b1346f56a0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    description: 'Luxurious faux fur coat with clean lines. Perfect for making a statement while staying warm.',
    sizes: ['XS', 'S', 'M', 'L'],
    featured: true,
    category: 'women'
  },
  {
    id: 'wf2',
    name: 'Down Puffer Coat with Detachable Collar',
    price: '₹14,900',
    image: 'https://images.unsplash.com/photo-1539533018447-63fcce2678e3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    description: 'Warm down puffer coat with a detachable faux fur collar. Practical and stylish for cold weather.',
    sizes: ['XS', 'S', 'M', 'L'],
    featured: true,
    category: 'women'
  },
  {
    id: 'w1',
    name: 'Silk Slip Dress',
    price: '₹9,900',
    image: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    description: 'Elegant silk slip dress with adjustable straps. Versatile piece for day-to-night styling.',
    sizes: ['XS', 'S', 'M', 'L'],
    category: 'women'
  },
  {
    id: 'w2',
    name: 'High-Waisted Wide Leg Trousers',
    price: '₹6,900',
    image: 'https://images.unsplash.com/photo-1551163943-3f6a855d1153?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    description: 'Sophisticated high-waisted trousers with a wide leg silhouette. Flattering and contemporary.',
    sizes: ['34', '36', '38', '40'],
    category: 'women'
  },
  {
    id: 'w3',
    name: 'Cashmere Turtleneck Sweater',
    price: '₹11,900',
    image: 'https://images.unsplash.com/photo-1608234807905-4466023792f5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    description: 'Sumptuous cashmere turtleneck with a relaxed fit. Luxurious essential for cold weather.',
    sizes: ['XS', 'S', 'M', 'L'],
    category: 'women'
  },
  {
    id: 'w4',
    name: 'Pleated Midi Skirt',
    price: '₹7,900',
    image: 'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    description: 'Elegant pleated midi skirt with fluid movement. A timeless addition to any wardrobe.',
    sizes: ['XS', 'S', 'M', 'L'],
    category: 'women'
  }
];

export default function WomenSection({ onProductClick }) {
  const featuredProducts = womenProducts.filter(product => product.featured);
  const regularProducts = womenProducts.filter(product => !product.featured);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <h1 className="text-4xl font-didot mb-12 text-center">THE LATEST TRENDS FROM ZARA'S NEW COLLECTION</h1>
      
      {/* Featured section with large images */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        {featuredProducts.map(product => (
          <div 
            key={product.id}
            className="relative cursor-pointer overflow-hidden rounded-lg"
            onClick={() => onProductClick(product)}
          >
            <div className="aspect-w-3 aspect-h-4">
              <img 
                src={product.image} 
                alt={product.name}
                className="w-full h-full object-cover transition-transform duration-300 hover:scale-105 rounded-lg"
              />
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-white bg-opacity-90">
              <h3 className="font-didot text-lg">{product.name}</h3>
              <p className="font-helvetica text-sm">{product.price}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Editorial section */}
      <div className="mb-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="col-span-1 md:col-span-2">
            <img 
              src="https://images.unsplash.com/photo-1483985988355-763728e1935b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80" 
              alt="Fashion editorial"
              className="w-full h-full object-cover rounded-lg"
            />
          </div>
          <div className="bg-black text-white p-8 flex flex-col justify-center rounded-lg">
            <h2 className="font-didot text-3xl mb-4">THE NEW SEASON</h2>
            <p className="font-helvetica">Discover our curated selection of pieces that define this season's most coveted trends. From statement outerwear to elegant essentials.</p>
          </div>
        </div>
      </div>

      {/* Regular products grid */}
      <div className="women-grid">
        {regularProducts.map(product => (
          <div 
            key={product.id}
            className="women-grid-item cursor-pointer"
            onClick={() => onProductClick(product)}
          >
            <div className="aspect-w-1 aspect-h-1 overflow-hidden rounded-lg">
              <img 
                src={product.image} 
                alt={product.name}
                className="w-full h-full object-cover transition-transform duration-300 hover:scale-105 rounded-lg"
              />
            </div>
            <h3 className="women-product-title">{product.name}</h3>
            <p className="women-product-price">{product.price}</p>
          </div>
        ))}
      </div>
    </div>
  );
}