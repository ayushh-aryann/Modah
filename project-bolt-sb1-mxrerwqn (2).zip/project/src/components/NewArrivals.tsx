import React, { useState } from 'react';
import { ChevronRight } from 'lucide-react';

export default function NewArrivals({ onProductClick }) {
  const [activeTab, setActiveTab] = useState('new-in');

  return (
    <section className="bg-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Editorial Header */}
        <div className="mb-16">
          <div className="grid grid-cols-2">
            <div className="col-span-1">
              <h1 className="text-[120px] font-didot leading-none text-[#f0f0f0]">01</h1>
              <h2 className="text-6xl font-didot leading-tight mt-[-20px]">new<br />collection</h2>
              
              {/* Navigation Tabs */}
              <div className="mt-12 flex space-x-8">
                <button 
                  className={`uppercase text-sm tracking-wider pb-1 border-b ${activeTab === 'new-in' ? 'border-black' : 'border-transparent'}`}
                  onClick={() => setActiveTab('new-in')}
                >
                  New in
                </button>
                <button 
                  className={`uppercase text-sm tracking-wider pb-1 border-b ${activeTab === 'woman' ? 'border-black' : 'border-transparent'}`}
                  onClick={() => setActiveTab('woman')}
                >
                  Woman
                </button>
                <button 
                  className={`uppercase text-sm tracking-wider pb-1 border-b ${activeTab === 'man' ? 'border-black' : 'border-transparent'}`}
                  onClick={() => setActiveTab('man')}
                >
                  Man
                </button>
                <button 
                  className={`uppercase text-sm tracking-wider pb-1 border-b ${activeTab === 'kids' ? 'border-black' : 'border-transparent'}`}
                  onClick={() => setActiveTab('kids')}
                >
                  Kids
                </button>
              </div>
            </div>
            
            {/* Editorial Image Collage */}
            <div className="col-span-1 grid grid-cols-6 grid-rows-6 gap-2">
              <div className="col-span-3 row-span-3 col-start-1 row-start-1">
                <img 
                  src="https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Man in turtleneck" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="col-span-3 row-span-4 col-start-4 row-start-1">
                <img 
                  src="https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Man in beige outfit" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="col-span-2 row-span-3 col-start-1 row-start-4">
                <img 
                  src="https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Clothing detail" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="col-span-3 row-span-2 col-start-3 row-start-5">
                <img 
                  src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Fashion detail" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Featured Collections */}
        <div className="mb-20">
          <h3 className="text-2xl font-didot mb-8">THE LATEST TRENDS FROM ZARA'S NEW COLLECTION</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Editorial Block 1 */}
            <div className="col-span-1 space-y-4">
              <div className="relative h-[500px] overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1548624149-f9b1346f56a0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Woman in coat" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 w-full p-4 bg-white bg-opacity-90">
                  <h4 className="font-didot text-lg">FAUX FUR COAT</h4>
                  <p className="text-sm">₹18,900</p>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <p className="text-sm text-gray-600 max-w-[80%]">
                  Luxurious faux fur coat with clean lines. Perfect for making a statement while staying warm.
                </p>
                <button 
                  className="p-2 border border-black rounded-full"
                  onClick={() => onProductClick({
                    id: 'wf1',
                    name: 'Faux Fur Coat',
                    price: '₹18,900',
                    image: 'https://images.unsplash.com/photo-1548624149-f9b1346f56a0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
                    description: 'Luxurious faux fur coat with clean lines. Perfect for making a statement while staying warm.',
                    sizes: ['XS', 'S', 'M', 'L']
                  })}
                >
                  <ChevronRight size={16} />
                </button>
              </div>
            </div>
            
            {/* Editorial Block 2 */}
            <div className="col-span-1 space-y-4">
              <div className="relative h-[500px] overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Suede jacket" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 w-full p-4 bg-white bg-opacity-90">
                  <h4 className="font-didot text-lg">SUEDE LEATHER JACKET</h4>
                  <p className="text-sm">₹29,900</p>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <p className="text-sm text-gray-600 max-w-[80%]">
                  Sophisticated jacket in soft suede leather. Perfect blend of casual and luxury.
                </p>
                <button 
                  className="p-2 border border-black rounded-full"
                  onClick={() => onProductClick({
                    id: 'j2',
                    name: 'Limited Edition Suede Leather Hooded Jacket',
                    price: '₹29,900',
                    image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
                    description: 'Sophisticated hooded jacket in soft suede leather. Perfect blend of casual and luxury.',
                    sizes: ['S', 'M', 'L', 'XL']
                  })}
                >
                  <ChevronRight size={16} />
                </button>
              </div>
            </div>
            
            {/* Editorial Block 3 */}
            <div className="col-span-1 space-y-4">
              <div className="relative h-[500px] overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1608234807905-4466023792f5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Cashmere sweater" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 w-full p-4 bg-white bg-opacity-90">
                  <h4 className="font-didot text-lg">CASHMERE TURTLENECK</h4>
                  <p className="text-sm">₹11,900</p>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <p className="text-sm text-gray-600 max-w-[80%]">
                  Sumptuous cashmere turtleneck with a relaxed fit. Luxurious essential for cold weather.
                </p>
                <button 
                  className="p-2 border border-black rounded-full"
                  onClick={() => onProductClick({
                    id: 'w4',
                    name: 'Cashmere Turtleneck Sweater',
                    price: '₹11,900',
                    image: 'https://images.unsplash.com/photo-1608234807905-4466023792f5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
                    description: 'Sumptuous cashmere turtleneck with a relaxed fit. Luxurious essential for cold weather.',
                    sizes: ['XS', 'S', 'M', 'L']
                  })}
                >
                  <ChevronRight size={16} />
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Editorial Banner */}
        <div className="mb-20 relative h-[600px] overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1483985988355-763728e1935b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80" 
            alt="Fashion editorial" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-white">
              <h2 className="text-8xl font-didot mb-4">1/F</h2>
              <p className="text-xl max-w-lg mx-auto">
                The latest trends from Zara's new collection
              </p>
            </div>
          </div>
        </div>
        
        {/* Bottom Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="relative h-[400px] overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1539533018447-63fcce2678e3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
              alt="Down puffer coat" 
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 w-full p-4 bg-white bg-opacity-90">
              <h4 className="font-didot text-lg">DOWN PUFFER COAT WITH DETACHABLE COLLAR</h4>
              <p className="text-sm">₹14,900</p>
            </div>
          </div>
          
          <div className="relative h-[400px] overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1543163521-1bf539c55dd2?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
              alt="Leather ankle boots" 
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 w-full p-4 bg-white bg-opacity-90">
              <h4 className="font-didot text-lg">LEATHER ANKLE BOOTS</h4>
              <p className="text-sm">₹14,900</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}