import React, { useState } from 'react';

export default function Newsletter() {
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle newsletter signup
    console.log('Newsletter signup:', email);
  };

  return (
    <div className="bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <h2 className="text-2xl font-didot mb-4">Join The Cult</h2>
          <p className="text-gray-600 mb-8">
            Sign up to our newsletter and get 10% off your first order
          </p>
          <form onSubmit={handleSubmit} className="max-w-md mx-auto">
            <div className="flex gap-4">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                className="flex-1 px-4 py-2 border border-gray-300 focus:ring-2 focus:ring-black focus:border-transparent rounded-lg"
                required
              />
              <button
                type="submit"
                className="interactive-button bg-black text-white hover:bg-gray-900"
              >
                Join
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}