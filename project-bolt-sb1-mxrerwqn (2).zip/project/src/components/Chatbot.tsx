import React, { useState, useCallback, useEffect } from 'react';
import { MessageCircle, X, Ruler, Camera, Shirt } from 'lucide-react';

interface Message {
  text: string;
  isBot: boolean;
  type?: 'size-recommendation' | 'general' | 'virtual-try-on';
}

interface SizeData {
  height?: number;
  weight?: number;
  gender?: 'male' | 'female' | 'other';
  fit?: 'slim' | 'regular' | 'loose';
  unit: 'metric' | 'imperial';
}

interface VirtualTryOnData {
  shoulderWidth?: number;
  chestWidth?: number;
  waistWidth?: number;
  hipWidth?: number;
  inseam?: number;
  selectedProduct?: {
    id: string;
    name: string;
    type: 'top' | 'bottom' | 'outerwear';
    size: string;
  };
}

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { 
      text: "Hi! I'm your Modah virtual stylist. I can help with virtual try-ons, sizing, and style advice. What would you like help with today?",
      isBot: true 
    }
  ]);
  const [input, setInput] = useState('');
  const [sizeData, setSizeData] = useState<SizeData>({
    unit: 'metric'
  });
  const [virtualTryOnData, setVirtualTryOnData] = useState<VirtualTryOnData>({});
  const [currentStep, setCurrentStep] = useState<'initial' | 'height' | 'weight' | 'gender' | 'fit' | 'virtual-try-on' | 'complete'>('initial');
  const [isVirtualTryOn, setIsVirtualTryOn] = useState(false);

  // Simulated virtual try-on data updates
  useEffect(() => {
    const tryOnDataInterval = setInterval(() => {
      if (isVirtualTryOn) {
        // Simulate receiving updated measurements from virtual try-on
        setVirtualTryOnData({
          shoulderWidth: 45 + Math.random() * 2,
          chestWidth: 100 + Math.random() * 4,
          waistWidth: 85 + Math.random() * 3,
          hipWidth: 95 + Math.random() * 3,
          inseam: 80 + Math.random() * 2,
          selectedProduct: {
            id: 'jacket-001',
            name: 'Double-Breasted Wool Suit Blazer',
            type: 'outerwear',
            size: 'L'
          }
        });
      }
    }, 2000);

    return () => clearInterval(tryOnDataInterval);
  }, [isVirtualTryOn]);

  const calculateBMI = (height: number, weight: number, unit: 'metric' | 'imperial'): number => {
    if (unit === 'metric') {
      return weight / Math.pow(height / 100, 2);
    } else {
      const heightCm = height * 2.54;
      const weightKg = weight * 0.453592;
      return weightKg / Math.pow(heightCm / 100, 2);
    }
  };

  const getSizeRecommendation = (bmi: number, gender: string, fit: string): string => {
    let baseSize = 'M';
    
    if (bmi < 18.5) {
      baseSize = gender === 'female' ? 'XS' : 'S';
    } else if (bmi >= 18.5 && bmi < 22) {
      baseSize = gender === 'female' ? 'S' : 'M';
    } else if (bmi >= 22 && bmi < 25) {
      baseSize = gender === 'female' ? 'M' : 'L';
    } else if (bmi >= 25 && bmi < 30) {
      baseSize = gender === 'female' ? 'L' : 'XL';
    } else {
      baseSize = gender === 'female' ? 'XL' : 'XXL';
    }

    if (fit === 'slim' && baseSize !== 'XS') {
      baseSize = getSmallerSize(baseSize);
    } else if (fit === 'loose' && baseSize !== 'XXL') {
      baseSize = getLargerSize(baseSize);
    }

    return baseSize;
  };

  const getSmallerSize = (size: string): string => {
    const sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];
    const currentIndex = sizes.indexOf(size);
    return currentIndex > 0 ? sizes[currentIndex - 1] : size;
  };

  const getLargerSize = (size: string): string => {
    const sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];
    const currentIndex = sizes.indexOf(size);
    return currentIndex < sizes.length - 1 ? sizes[currentIndex + 1] : size;
  };

  const analyzeFit = (data: VirtualTryOnData): string => {
    if (!data.selectedProduct) return '';

    const product = data.selectedProduct;
    let feedback = '';

    switch (product.type) {
      case 'top':
      case 'outerwear':
        if (data.shoulderWidth && data.shoulderWidth > 47) {
          feedback += "The shoulders appear slightly tight. Consider going up a size for better mobility. ";
        }
        if (data.chestWidth && data.chestWidth > 105) {
          feedback += "There's some pulling across the chest. A larger size would provide a more comfortable fit. ";
        }
        break;
      case 'bottom':
        if (data.waistWidth && data.waistWidth > 90) {
          feedback += "The waist seems a bit snug. Try our next size up for a more comfortable fit. ";
        }
        if (data.hipWidth && data.hipWidth > 100) {
          feedback += "You might want more room in the hips. Consider a size up or a different cut. ";
        }
        break;
    }

    return feedback || "The current size appears to fit well! ";
  };

  const handleVirtualTryOn = () => {
    if (!virtualTryOnData.selectedProduct) return;

    const fitAnalysis = analyzeFit(virtualTryOnData);
    const response = `Virtual Try-On Analysis for ${virtualTryOnData.selectedProduct.name}:

${fitAnalysis}

Would you like to:
1. Try a different size
2. See similar styles
3. Add to cart`;

    setMessages(prev => [...prev, { 
      text: response, 
      isBot: true, 
      type: 'virtual-try-on' 
    }]);
  };

  const handleSizeRecommendation = () => {
    if (!sizeData.height || !sizeData.weight || !sizeData.gender || !sizeData.fit) return;

    const bmi = calculateBMI(sizeData.height, sizeData.weight, sizeData.unit);
    const recommendedSize = getSizeRecommendation(bmi, sizeData.gender, sizeData.fit);

    const response = `Based on your measurements:
Height: ${sizeData.height}${sizeData.unit === 'metric' ? ' cm' : ' inches'}
Weight: ${sizeData.weight}${sizeData.unit === 'metric' ? ' kg' : ' lbs'}

I recommend size ${recommendedSize} for a ${sizeData.fit} fit.

Would you like to:
1. Try this size virtually
2. See available items in this size
3. Get styling tips`;

    setMessages(prev => [...prev, { 
      text: response, 
      isBot: true, 
      type: 'size-recommendation' 
    }]);
    setCurrentStep('complete');
  };

  const getStylingTips = (product: VirtualTryOnData['selectedProduct']): string => {
    if (!product) return '';

    const tips = {
      outerwear: [
        "Layer with a slim-fit sweater or shirt underneath for a polished look",
        "Roll the sleeves slightly for a casual vibe",
        "Try contrasting colors for the inner layers",
      ],
      top: [
        "Tuck in for a more formal appearance",
        "Leave untucked with fitted pants for a casual look",
        "Add a belt to define the waist",
      ],
      bottom: [
        "Pair with a fitted top to balance proportions",
        "Choose ankle-length for a modern silhouette",
        "Add loafers or sneakers depending on the occasion",
      ]
    };

    return tips[product.type].join("\n");
  };

  const processUserInput = (input: string) => {
    setMessages(prev => [...prev, { text: input, isBot: false }]);

    const lowercaseInput = input.toLowerCase();

    if (isVirtualTryOn) {
      if (lowercaseInput.includes('fit') || lowercaseInput.includes('how')) {
        handleVirtualTryOn();
        return;
      }
      
      if (lowercaseInput.includes('style') || lowercaseInput.includes('wear')) {
        const tips = getStylingTips(virtualTryOnData.selectedProduct);
        setMessages(prev => [...prev, { 
          text: `Styling Tips:\n\n${tips}`, 
          isBot: true 
        }]);
        return;
      }
    }

    switch (currentStep) {
      case 'initial':
        if (lowercaseInput.includes('virtual') || lowercaseInput.includes('try on')) {
          setIsVirtualTryOn(true);
          setMessages(prev => [...prev, {
            text: "I'll analyze the virtual try-on and provide fit feedback. Please stand in front of the camera and try on the item you're interested in.",
            isBot: true
          }]);
          setCurrentStep('virtual-try-on');
        } else if (lowercaseInput.includes('size')) {
          setMessages(prev => [...prev, {
            text: "Let's find your perfect size. Would you prefer measurements in metric (cm/kg) or imperial (inches/lbs)?",
            isBot: true
          }]);
          setCurrentStep('height');
        } else {
          setMessages(prev => [...prev, {
            text: "I can help with virtual try-ons, sizing, or style advice. What would you like to focus on?",
            isBot: true
          }]);
        }
        break;

      case 'height':
        const height = parseFloat(input.match(/\d+(\.\d+)?/)?.[0] || '0');
        if (height > 0) {
          setSizeData(prev => ({ ...prev, height }));
          setMessages(prev => [...prev, {
            text: "Great! Now, what's your weight?",
            isBot: true
          }]);
          setCurrentStep('weight');
        } else {
          setMessages(prev => [...prev, {
            text: "I couldn't understand that measurement. Please enter your height in numbers (e.g., 175 cm or 69 inches).",
            isBot: true
          }]);
        }
        break;

      case 'weight':
        const weight = parseFloat(input.match(/\d+(\.\d+)?/)?.[0] || '0');
        if (weight > 0) {
          setSizeData(prev => ({ ...prev, weight }));
          setMessages(prev => [...prev, {
            text: "What's your gender? (male/female/other)",
            isBot: true
          }]);
          setCurrentStep('gender');
        } else {
          setMessages(prev => [...prev, {
            text: "I couldn't understand that measurement. Please enter your weight in numbers (e.g., 70 kg or 154 lbs).",
            isBot: true
          }]);
        }
        break;

      case 'gender':
        const gender = lowercaseInput;
        if (['male', 'female', 'other'].includes(gender)) {
          setSizeData(prev => ({ ...prev, gender: gender as 'male' | 'female' | 'other' }));
          setMessages(prev => [...prev, {
            text: "What's your preferred fit? (slim/regular/loose)",
            isBot: true
          }]);
          setCurrentStep('fit');
        } else {
          setMessages(prev => [...prev, {
            text: "Please specify your gender as male, female, or other.",
            isBot: true
          }]);
        }
        break;

      case 'fit':
        const fit = lowercaseInput;
        if (['slim', 'regular', 'loose'].includes(fit)) {
          setSizeData(prev => ({ ...prev, fit: fit as 'slim' | 'regular' | 'loose' }));
          handleSizeRecommendation();
        } else {
          setMessages(prev => [...prev, {
            text: "Please specify your preferred fit as slim, regular, or loose.",
            isBot: true
          }]);
        }
        break;

      case 'virtual-try-on':
        if (lowercaseInput.includes('yes') || lowercaseInput.includes('show')) {
          handleVirtualTryOn();
        } else {
          setMessages(prev => [...prev, {
            text: "Would you like me to analyze the fit or suggest styling options?",
            isBot: true
          }]);
        }
        break;

      case 'complete':
        if (lowercaseInput.includes('1') || lowercaseInput.includes('virtual')) {
          setIsVirtualTryOn(true);
          setMessages(prev => [...prev, {
            text: "Great! Let's try it virtually. Please stand in front of the camera and I'll analyze the fit.",
            isBot: true
          }]);
          setCurrentStep('virtual-try-on');
        } else if (lowercaseInput.includes('2') || lowercaseInput.includes('see')) {
          setMessages(prev => [...prev, {
            text: "I'll show you some great options in your recommended size. What type of clothing are you interested in?",
            isBot: true
          }]);
        } else if (lowercaseInput.includes('3') || lowercaseInput.includes('style')) {
          setMessages(prev => [...prev, {
            text: "I'd be happy to provide styling tips! What's your preferred style: casual, business, or formal?",
            isBot: true
          }]);
        } else {
          setMessages(prev => [...prev, {
            text: "Is there anything specific you'd like to know about the fit or styling?",
            isBot: true
          }]);
        }
        break;
    }
  };

  const handleSend = () => {
    if (!input.trim()) return;
    processUserInput(input.trim());
    setInput('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <>
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-4 right-4 bg-black text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5 flex items-center space-x-2"
        >
          <MessageCircle size={24} />
          <span className="hidden md:inline">Virtual Stylist</span>
        </button>
      )}

      <div 
        className={`fixed bottom-4 right-4 w-96 bg-white rounded-lg shadow-2xl transition-all transform ${
          isOpen ? 'scale-100 opacity-100' : 'scale-0 opacity-0'
        }`}
      >
        <div className="p-4 border-b flex justify-between items-center bg-black text-white rounded-t-lg">
          <div className="flex items-center space-x-2">
            {isVirtualTryOn ? <Camera size={20} /> : <Shirt size={20} />}
            <h3 className="font-didot">Virtual Stylist</h3>
          </div>
          <button 
            onClick={() => setIsOpen(false)}
            className="text-white hover:text-gray-300 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        <div className="h-96 overflow-y-auto p-4 space-y-4">
          {messages.map((msg, i) => (
            <div 
              key={i} 
              className={`flex ${msg.isBot ? 'justify-start' : 'justify-end'}`}
            >
              <div 
                className={`max-w-[80%] p-3 rounded-lg ${
                  msg.isBot 
                    ? 'bg-gray-100' 
                    : 'bg-black text-white'
                } ${
                  msg.type === 'virtual-try-on' || msg.type === 'size-recommendation'
                    ? 'whitespace-pre-line font-mono text-sm' 
                    : ''
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 border-t">
          <div className="flex space-x-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:border-black"
            />
            <button
              onClick={handleSend}
              className="px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-900 transition-colors"
            >
              Send
            </button>
          </div>
        </div>
      </div>
    </>
  );
}