import React from 'react';

export default function Hero({ onStartShopping }) {
  return (
    <div className="relative h-screen bg-white">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80")'
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-30" />
      </div>
      
      <div className="relative h-full flex flex-col justify-between p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-4xl font-didot text-white tracking-wider">MODAH</h1>
        </div>

        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-7xl font-bd-sans text-white mb-8">Redefine Your Style</h2>
          <button 
            onClick={onStartShopping}
            className="minimal-button-primary text-lg shadow-lg hover:shadow-xl hover:scale-105 transform transition-all rounded-lg"
          >
            SHOP NOW
          </button>
        </div>

        <div className="max-w-4xl mx-auto text-center text-white">
          <p className="text-lg font-helvetica">
            At Modah, fashion is more than just clothing—it's a statement of style, confidence, and individuality.
          </p>
        </div>
      </div>
    </div>
  );
}