import React, { useEffect, useRef, useState } from 'react';
import { ChevronRight } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  price: string;
  image: string;
  description: string;
  sizes: string[];
  category: string;
}

interface MensNewArrivalsProps {
  onProductClick: (product: Product) => void;
}

export default function MensNewArrivals({ onProductClick }: MensNewArrivalsProps) {
  const [activeTab, setActiveTab] = useState('all');
  const [visibleItems, setVisibleItems] = useState<Set<string>>(new Set());
  const observerRefs = useRef<Map<string, HTMLDivElement>>(new Map());
  const parallaxRef = useRef<HTMLDivElement>(null);
  const [scrollY, setScrollY] = useState(0);
  const prefersReducedMotion = useRef(window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  const mensProducts = [
    {
      id: 'mn1',
      name: 'Technical Hooded Jacket',
      price: '₹12,900',
      image: 'https://images.unsplash.com/photo-1548126032-079a0fb0099d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Lightweight technical jacket with hood. Water-resistant fabric with minimalist design.',
      sizes: ['S', 'M', 'L', 'XL'],
      category: 'outerwear'
    },
    {
      id: 'mn2',
      name: 'Oversized Sweatshirt',
      price: '₹4,900',
      image: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Relaxed fit sweatshirt with dropped shoulders. Made from premium cotton blend.',
      sizes: ['S', 'M', 'L', 'XL'],
      category: 'tops'
    },
    {
      id: 'mn3',
      name: 'Printed T-Shirt',
      price: '₹2,900',
      image: 'https://images.unsplash.com/photo-1503341504253-dff4815485f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Abstract print t-shirt with relaxed fit. Made from organic cotton.',
      sizes: ['S', 'M', 'L', 'XL'],
      category: 'tops'
    },
    {
      id: 'mn4',
      name: 'Slim Fit Trousers',
      price: '₹5,900',
      image: 'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Tailored slim-fit trousers in premium fabric. Modern silhouette with clean lines.',
      sizes: ['30', '32', '34', '36'],
      category: 'bottoms'
    },
    {
      id: 'mn5',
      name: 'Minimal Bomber Jacket',
      price: '₹9,900',
      image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Contemporary bomber jacket with minimal details. Lightweight and versatile.',
      sizes: ['S', 'M', 'L', 'XL'],
      category: 'outerwear'
    },
    {
      id: 'mn6',
      name: 'Structured Overshirt',
      price: '₹7,900',
      image: 'https://images.unsplash.com/photo-1617137968427-85924c800a22?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Versatile overshirt with structured silhouette. Perfect for layering.',
      sizes: ['S', 'M', 'L', 'XL'],
      category: 'tops'
    }
  ];

  const filteredProducts = activeTab === 'all' 
    ? mensProducts 
    : mensProducts.filter(product => product.category === activeTab);

  useEffect(() => {
    // Reset visibility when tab changes
    setVisibleItems(new Set());
    
    // Setup Intersection Observer
    const observerCallback = (entries: IntersectionObserverEntry[]) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          setVisibleItems(prev => new Set(prev).add(entry.target.id));
        }
      });
    };

    const observerOptions = {
      root: null,
      rootMargin: '0px',
      threshold: 0.15
    };

    const observer = new IntersectionObserver(observerCallback, observerOptions);
    
    // Observe all product elements
    observerRefs.current.forEach((ref) => {
      if (ref) observer.observe(ref);
    });

    // Handle scroll for parallax effect
    const handleScroll = () => {
      if (prefersReducedMotion.current) return;
      setScrollY(window.scrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      observer.disconnect();
      window.removeEventListener('scroll', handleScroll);
    };
  }, [activeTab]);

  // Apply parallax effect
  useEffect(() => {
    if (parallaxRef.current && !prefersReducedMotion.current) {
      const translateY = scrollY * 0.5; // 0.5 scroll ratio
      parallaxRef.current.style.transform = `translateY(${translateY}px)`;
    }
  }, [scrollY]);

  const setObserverRef = (id: string, element: HTMLDivElement | null) => {
    if (element) {
      observerRefs.current.set(id, element);
    } else {
      observerRefs.current.delete(id);
    }
  };

  return (
    <section className="bg-white">
      {/* Hero Section with Parallax */}
      <div className="relative h-[70vh] overflow-hidden">
        <div 
          ref={parallaxRef}
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1548126032-079a0fb0099d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80")',
            transform: 'translateY(0)'
          }}
        >
          <div className="absolute inset-0 bg-black bg-opacity-40" />
        </div>
        
        <div className="relative h-full flex flex-col justify-center items-center p-8 text-center">
          <h1 className="text-7xl font-didot text-white mb-4">MEN'S NEW ARRIVALS</h1>
          <p className="text-xl text-white max-w-2xl font-helvetica">
            Discover our latest collection of premium menswear, designed for the modern man.
          </p>
        </div>
      </div>

      {/* Editorial Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="col-span-1">
              <h1 className="text-[120px] font-didot leading-none text-[#f0f0f0]">02</h1>
              <h2 className="text-6xl font-didot leading-tight mt-[-20px]">men's<br />collection</h2>
              
              {/* Navigation Tabs */}
              <div className="mt-12 flex space-x-8">
                <button 
                  className={`uppercase text-sm tracking-wider pb-1 border-b ${activeTab === 'all' ? 'border-black' : 'border-transparent'}`}
                  onClick={() => setActiveTab('all')}
                >
                  All
                </button>
                <button 
                  className={`uppercase text-sm tracking-wider pb-1 border-b ${activeTab === 'outerwear' ? 'border-black' : 'border-transparent'}`}
                  onClick={() => setActiveTab('outerwear')}
                >
                  Outerwear
                </button>
                <button 
                  className={`uppercase text-sm tracking-wider pb-1 border-b ${activeTab === 'tops' ? 'border-black' : 'border-transparent'}`}
                  onClick={() => setActiveTab('tops')}
                >
                  Tops
                </button>
                <button 
                  className={`uppercase text-sm tracking-wider pb-1 border-b ${activeTab === 'bottoms' ? 'border-black' : 'border-transparent'}`}
                  onClick={() => setActiveTab('bottoms')}
                >
                  Bottoms
                </button>
              </div>
            </div>
            
            {/* Editorial Image */}
            <div className="col-span-1 overflow-hidden rounded-lg shadow-[0_2px_8px_rgba(0,0,0,0.1)]">
              <img 
                src="https://images.unsplash.com/photo-1550246140-5119ae4790b8?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="Editorial fashion" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>

        {/* Product Grid with Animations */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <div 
              key={product.id}
              id={product.id}
              ref={(el) => setObserverRef(product.id, el)}
              className={`
                group relative overflow-hidden rounded-lg shadow-[0_2px_8px_rgba(0,0,0,0.1)]
                transform transition-all duration-300 ease-out
                ${visibleItems.has(product.id) ? 'opacity-100' : 'opacity-0 translate-y-8'}
              `}
              style={{
                transitionProperty: 'opacity, transform',
                transitionTimingFunction: 'cubic-bezier(0.4, 0, 0.2, 1), ease-out',
                transitionDuration: '400ms, 300ms'
              }}
              onClick={() => onProductClick(product)}
            >
              <div className="aspect-w-3 aspect-h-4 overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover object-center transition-transform duration-300 ease-out group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-opacity duration-300 ease-in-out" />
              </div>
              
              <div className="absolute bottom-0 left-0 right-0 p-6 bg-white bg-opacity-90 transform transition-transform duration-300 ease-out translate-y-0 group-hover:translate-y-0">
                <h3 className="font-didot text-lg">{product.name}</h3>
                <p className="text-sm text-gray-900">{product.price}</p>
                
                <div className="h-0 group-hover:h-auto overflow-hidden opacity-0 group-hover:opacity-100 transition-all duration-300 ease-in-out mt-2">
                  <p className="text-sm text-gray-600 mb-4">{product.description}</p>
                  <div className="flex justify-between items-center">
                    <div className="flex space-x-2">
                      {product.sizes.map(size => (
                        <span key={size} className="text-xs px-2 py-1 border border-gray-300 rounded">
                          {size}
                        </span>
                      ))}
                    </div>
                    <button className="p-2 border border-black rounded-full">
                      <ChevronRight size={16} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Editorial Banner */}
      <div className="relative h-[600px] overflow-hidden my-20">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1550246140-29f40b909e5a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80")'
          }}
        >
          <div className="absolute inset-0 bg-black bg-opacity-30" />
        </div>
        
        <div className="relative h-full flex items-center justify-center">
          <div className="text-center text-white">
            <h2 className="text-8xl font-didot mb-4">MODAH</h2>
            <p className="text-xl max-w-lg mx-auto font-helvetica">
              Redefine your style with our premium collection
            </p>
          </div>
        </div>
      </div>

      {/* Featured Products */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl font-didot mb-12 text-center">FEATURED PIECES</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="relative h-[500px] overflow-hidden rounded-lg shadow-[0_2px_8px_rgba(0,0,0,0.1)]">
            <img 
              src="https://images.unsplash.com/photo-1516826957135-700dedea698c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
              alt="Featured product" 
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 w-full p-6 bg-white bg-opacity-90">
              <h3 className="font-didot text-lg">PREMIUM WOOL SWEATER</h3>
              <p className="text-sm">₹7,900</p>
            </div>
          </div>
          
          <div className="relative h-[500px] overflow-hidden rounded-lg shadow-[0_2px_8px_rgba(0,0,0,0.1)]">
            <img 
              src="https://images.unsplash.com/photo-1617137968427-85924c800a22?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
              alt="Featured product" 
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 w-full p-6 bg-white bg-opacity-90">
              <h3 className="font-didot text-lg">STRUCTURED BLAZER</h3>
              <p className="text-sm">₹12,900</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}