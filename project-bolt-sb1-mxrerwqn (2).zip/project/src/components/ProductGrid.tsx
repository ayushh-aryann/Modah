import React, { useState, useEffect } from 'react';

const products = {
  jackets: [
    {
      id: 'j1',
      name: 'Limited Edition Suede Leather Jacket',
      price: '₹34,900',
      image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Premium suede leather jacket with minimalist design. Features clean lines and superior craftsmanship.',
      sizes: ['S', 'M', 'L', 'XL'],
      category: 'jackets'
    },
    {
      id: 'j2',
      name: 'Limited Edition Suede Leather Hooded Jacket',
      price: '₹29,900',
      image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Sophisticated hooded jacket in soft suede leather. Perfect blend of casual and luxury.',
      sizes: ['S', 'M', 'L', 'XL'],
      category: 'jackets'
    },
    {
      id: 'j3',
      name: 'Suede Leather Jacket',
      price: '₹34,900',
      image: 'https://images.unsplash.com/photo-1509539662397-116cb90542f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Classic suede jacket with modern details. Features minimal hardware and clean silhouette.',
      sizes: ['S', 'M', 'L', 'XL'],
      category: 'jackets'
    },
    {
      id: 'j4',
      name: 'Cropped Fit Leather Jacket',
      price: '₹22,900',
      image: 'https://images.unsplash.com/photo-1521223890158-f9f7c3d5d504?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Contemporary cropped leather jacket. Perfect for layering with modern proportions.',
      sizes: ['S', 'M', 'L', 'XL'],
      category: 'jackets'
    },
  ],
  men: [
    {
      id: 'm1',
      name: 'Premium Cotton T-Shirt',
      price: '₹2,900',
      image: 'https://images.unsplash.com/photo-1586363104862-3a5e2ab60d99?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Luxurious cotton t-shirt with a relaxed fit. Perfect for everyday wear with exceptional comfort.',
      sizes: ['S', 'M', 'L', 'XL'],
      category: 'men'
    },
    {
      id: 'm2',
      name: 'Slim Fit Chino Trousers',
      price: '₹4,900',
      image: 'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Tailored slim-fit chinos made from premium cotton. Versatile and sophisticated for any occasion.',
      sizes: ['30', '32', '34', '36'],
      category: 'men'
    },
    {
      id: 'm3',
      name: 'Merino Wool Sweater',
      price: '₹7,900',
      image: 'https://images.unsplash.com/photo-1516826957135-700dedea698c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Soft merino wool sweater with ribbed details. Lightweight yet warm for transitional seasons.',
      sizes: ['S', 'M', 'L', 'XL'],
      category: 'men'
    },
    {
      id: 'm4',
      name: 'Structured Blazer',
      price: '₹12,900',
      image: 'https://images.unsplash.com/photo-1617137968427-85924c800a22?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Impeccably tailored blazer with a modern silhouette. Perfect for elevating any outfit.',
      sizes: ['48', '50', '52', '54'],
      category: 'men'
    },
  ],
  women: [
    {
      id: 'w1',
      name: 'Oversized Wool Coat',
      price: '₹18,900',
      image: 'https://images.unsplash.com/photo-1548624149-f9b1346f56a0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Luxurious oversized wool coat with clean lines. Perfect for making a statement while staying warm.',
      sizes: ['XS', 'S', 'M', 'L'],
      category: 'women'
    },
    {
      id: 'w2',
      name: 'Silk Slip Dress',
      price: '₹9,900',
      image: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Elegant silk slip dress with adjustable straps. Versatile piece for day-to-night styling.',
      sizes: ['XS', 'S', 'M', 'L'],
      category: 'women'
    },
    {
      id: 'w3',
      name: 'High-Waisted Wide Leg Trousers',
      price: '₹6,900',
      image: 'https://images.unsplash.com/photo-1551163943-3f6a855d1153?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Sophisticated high-waisted trousers with a wide leg silhouette. Flattering and contemporary.',
      sizes: ['34', '36', '38', '40'],
      category: 'women'
    },
    {
      id: 'w4',
      name: 'Cashmere Turtleneck Sweater',
      price: '₹11,900',
      image: 'https://images.unsplash.com/photo-1608234807905-4466023792f5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      description: 'Sumptuous cashmere turtleneck with a relaxed fit. Luxurious essential for cold weather.',
      sizes: ['XS', 'S', 'M', 'L'],
      category: 'women'
    },
  ]
};

export default function ProductGrid({ onProductClick, initialCategory = 'all' }) {
  const [activeCategory, setActiveCategory] = useState(initialCategory);
  const [view, setView] = useState(2); // 2 or 3 columns
  
  useEffect(() => {
    setActiveCategory(initialCategory);
  }, [initialCategory]);

  const displayProducts = activeCategory === 'all' 
    ? [...products.jackets, ...products.men, ...products.women]
    : products[activeCategory] || [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="flex justify-between items-center mb-12">
        <div className="flex space-x-8">
          <button 
            onClick={() => setActiveCategory('all')}
            className={`font-bd-sans text-lg transition-colors ${
              activeCategory === 'all' 
                ? 'text-black' 
                : 'text-gray-400 hover:text-black'
            }`}
          >
            ALL
          </button>
          <button 
            onClick={() => setActiveCategory('jackets')}
            className={`font-bd-sans text-lg transition-colors ${
              activeCategory === 'jackets' 
                ? 'text-black' 
                : 'text-gray-400 hover:text-black'
            }`}
          >
            JACKETS
          </button>
          <button 
            onClick={() => setActiveCategory('men')}
            className={`font-bd-sans text-lg transition-colors ${
              activeCategory === 'men' 
                ? 'text-black' 
                : 'text-gray-400 hover:text-black'
            }`}
          >
            MEN
          </button>
          <button 
            onClick={() => setActiveCategory('women')}
            className={`font-bd-sans text-lg transition-colors ${
              activeCategory === 'women' 
                ? 'text-black' 
                : 'text-gray-400 hover:text-black'
            }`}
          >
            WOMEN
          </button>
        </div>

        <div className="flex items-center space-x-4">
          <span className="text-sm text-gray-500">VIEW</span>
          <button
            onClick={() => setView(2)}
            className={`px-2 ${view === 2 ? 'text-black' : 'text-gray-400'}`}
          >
            2
          </button>
          <button
            onClick={() => setView(3)}
            className={`px-2 ${view === 3 ? 'text-black' : 'text-gray-400'}`}
          >
            3
          </button>
        </div>
      </div>

      <div className={`grid gap-8 ${
        view === 2 
          ? 'grid-cols-1 sm:grid-cols-2' 
          : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
      }`}>
        {displayProducts.map((product) => (
          <div 
            key={product.id} 
            className="product-card"
            onClick={() => onProductClick(product)}
          >
            <div className="product-card-image">
              <img
                src={product.image}
                alt={product.name}
                className="h-full w-full object-cover object-center group-hover:opacity-75 transition-opacity duration-300 rounded-lg"
              />
            </div>
            <div className="product-card-content">
              <h3 className="text-sm font-bd-sans">{product.name}</h3>
              <p className="text-sm text-gray-900">{product.price}</p>
              <p className="text-sm text-gray-500 font-helvetica line-clamp-2">
                {product.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}