import React, { useState } from 'react';
import { X } from 'lucide-react';

export default function ProductDetails({ product, onClose, onAddToCart }) {
  const [selectedSize, setSelectedSize] = useState('');
  const [quantity, setQuantity] = useState(1);

  const handleAddToCart = () => {
    if (!selectedSize) {
      alert('Please select a size');
      return;
    }
    onAddToCart({ ...product, selectedSize }, quantity);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white max-w-4xl w-full mx-4 p-8 rounded-lg shadow-lg">
        <div className="flex justify-end mb-4">
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-black transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="aspect-w-1 aspect-h-1 bg-gray-100 rounded-lg overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover object-center"
            />
          </div>

          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-didot mb-2">{product.name}</h1>
              <p className="text-xl text-gray-900 mb-4">{product.price}</p>
              <p className="text-gray-600 font-helvetica">{product.description}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Size
              </label>
              <div className="grid grid-cols-4 gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    className={`py-2 text-center border transition-colors rounded-lg ${
                      selectedSize === size
                        ? 'border-black bg-black text-white'
                        : 'border-gray-300 hover:border-black'
                    }`}
                    onClick={() => setSelectedSize(size)}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Quantity
              </label>
              <div className="flex items-center space-x-4">
                <button
                  className="w-8 h-8 border border-gray-300 flex items-center justify-center hover:border-black transition-colors rounded-lg"
                  onClick={() => setQuantity(q => Math.max(1, q - 1))}
                >
                  -
                </button>
                <span className="font-bd-sans">{quantity}</span>
                <button
                  className="w-8 h-8 border border-gray-300 flex items-center justify-center hover:border-black transition-colors rounded-lg"
                  onClick={() => setQuantity(q => q + 1)}
                >
                  +
                </button>
              </div>
            </div>

            <button
              onClick={handleAddToCart}
              className="w-full bg-black text-white py-3 hover:bg-gray-900 transition-colors font-bd-sans rounded-lg shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 ease-in-out"
            >
              Add to Cart
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}