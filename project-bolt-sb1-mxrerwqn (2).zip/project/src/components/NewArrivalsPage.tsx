import React, { useState } from 'react';
import ProductCarousel from './ProductCarousel';

interface Product {
  id: string;
  name: string;
  price: string;
  image: string;
  description: string;
  sizes: string[];
  category: string;
}

interface NewArrivalsPageProps {
  onProductClick: (product: Product) => void;
}

export default function NewArrivalsPage({ onProductClick }: NewArrivalsPageProps) {
  const [activeCategory, setActiveCategory] = useState('all');
  
  const newArrivalsProducts = [
    {
      id: 'na1',
      name: 'DOUBLE-BREASTED 100% WOOL SUIT BLAZER',
      price: '₹15,550',
      image: 'https://static.zara.net/photos///2024/V/0/2/p/1564/430/800/2/w/563/1564430800_1_1_1.jpg?ts=1705593339614',
      description: 'Premium wool blazer with double-breasted design. Features clean lines and superior craftsmanship.',
      sizes: ['S', 'M', 'L', 'XL'],
      category: 'formal'
    },
    {
      id: 'na2',
      name: 'REGULAR FIT SHIRT',
      price: '₹4,350',
      image: 'https://static.zara.net/photos///2024/V/0/2/p/6103/331/403/2/w/563/6103331403_2_1_1.jpg?ts=1705593339681',
      description: 'Classic regular fit shirt in light blue stripe pattern. Perfect for formal and casual occasions.',
      sizes: ['S', 'M', 'L', 'XL'],
      category: 'formal'
    },
    {
      id: 'na3',
      name: '100% WOOL SUIT TROUSERS',
      price: '₹10,950',
      image: 'https://static.zara.net/photos///2024/V/0/2/p/1564/430/800/2/w/563/1564430800_2_1_1.jpg?ts=1705593339681',
      description: 'Premium wool trousers with tailored fit. Perfect match for the wool suit blazer.',
      sizes: ['30', '32', '34', '36'],
      category: 'formal'
    },
    {
      id: 'na4',
      name: 'TEXTURED SUIT BLAZER',
      price: '₹12,990',
      image: 'https://static.zara.net/photos///2024/V/0/2/p/0706/331/710/2/w/563/0706331710_2_1_1.jpg?ts=1705593339614',
      description: 'Sophisticated blazer in textured fabric. Features a modern silhouette with classic details.',
      sizes: ['S', 'M', 'L', 'XL'],
      category: 'formal'
    },
    {
      id: 'na5',
      name: 'LEATHER MONK SHOES',
      price: '₹9,990',
      image: 'https://static.zara.net/photos///2024/V/1/2/p/2702/920/800/2/w/563/2702920800_6_2_1.jpg?ts=1705593339614',
      description: 'Premium leather monk strap shoes. Classic design with modern comfort.',
      sizes: ['40', '41', '42', '43', '44'],
      category: 'shoes'
    },
    {
      id: 'na6',
      name: 'SLIM FIT SUIT BLAZER',
      price: '₹14,990',
      image: 'https://static.zara.net/photos///2024/V/0/2/p/1564/430/710/2/w/563/1564430710_2_1_1.jpg?ts=1705593339614',
      description: 'Modern slim fit blazer in premium fabric. Perfect for contemporary formal wear.',
      sizes: ['S', 'M', 'L', 'XL'],
      category: 'formal'
    }
  ];
  
  const filteredProducts = activeCategory === 'all' 
    ? newArrivalsProducts 
    : newArrivalsProducts.filter(product => product.category === activeCategory);
  
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="relative h-[90vh] overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url("https://static.zara.net/photos///contents/mkt/spots/ss24-north-man-new/subhome-xmedia-04//w/1920/IMAGE-landscape-fill-c060264d-8651-4521-8b83-7e0745ed3690-default_0.jpg?ts=1705593339614")'
          }}
        >
          <div className="absolute inset-0 bg-black bg-opacity-20" />
        </div>
        
        <div className="relative h-full flex flex-col justify-center items-center p-8 text-center">
          <h1 className="text-8xl font-didot text-white mb-4">THE NEW</h1>
          <p className="text-xl text-white max-w-2xl font-helvetica uppercase tracking-widest">
            SPRING SUMMER 2024
          </p>
        </div>
      </div>
      
      {/* Category Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-wrap justify-center space-x-8">
          <button 
            className={`uppercase text-sm tracking-wider pb-1 border-b mb-4 ${activeCategory === 'all' ? 'border-black' : 'border-transparent'}`}
            onClick={() => setActiveCategory('all')}
          >
            All New
          </button>
          <button 
            className={`uppercase text-sm tracking-wider pb-1 border-b mb-4 ${activeCategory === 'formal' ? 'border-black' : 'border-transparent'}`}
            onClick={() => setActiveCategory('formal')}
          >
            Formal
          </button>
          <button 
            className={`uppercase text-sm tracking-wider pb-1 border-b mb-4 ${activeCategory === 'shoes' ? 'border-black' : 'border-transparent'}`}
            onClick={() => setActiveCategory('shoes')}
          >
            Shoes
          </button>
        </div>
      </div>
      
      {/* Product Carousel */}
      <ProductCarousel 
        products={filteredProducts} 
        onProductClick={onProductClick} 
        title={activeCategory === 'all' ? 'NEW IN' : `${activeCategory.toUpperCase()} COLLECTION`}
      />
      
      {/* Editorial Banner */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-0 my-20">
        <div 
          className="relative h-[600px] overflow-hidden"
          style={{
            backgroundImage: 'url("https://static.zara.net/photos///contents/mkt/spots/ss24-north-man-new/subhome-xmedia-04-2//w/1920/IMAGE-landscape-default-fill-8de0d07f-f6d3-4ad9-8478-f6d6c11197e8-default_0.jpg?ts=1705593339614")',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        />
        <div 
          className="relative h-[600px] overflow-hidden bg-[#f8f8f8] flex items-center justify-center"
        >
          <div className="text-center">
            <h2 className="text-6xl font-didot mb-4">The New</h2>
            <p className="text-xl uppercase tracking-widest">Spring Summer 2024</p>
          </div>
        </div>
      </div>
      
      {/* Featured Collections */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl font-didot mb-12 text-center uppercase tracking-widest">Featured</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div 
            className="relative h-[700px] overflow-hidden cursor-pointer group"
            onClick={() => setActiveCategory('formal')}
          >
            <img 
              src="https://static.zara.net/photos///contents/mkt/spots/ss24-north-man-suits/subhome-xmedia-04//w/1920/IMAGE-landscape-fill-8d1e69c1-0548-4c52-b468-7a0440f68f7b-default_0.jpg?ts=1705593339614" 
              alt="Formal collection" 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-black bg-opacity-20 group-hover:bg-opacity-30 transition-opacity duration-300" />
            <div className="absolute bottom-0 left-0 w-full p-8 text-white">
              <h3 className="font-didot text-4xl mb-2">SUITS</h3>
              <p className="text-sm uppercase tracking-widest">Explore the Collection</p>
            </div>
          </div>
          
          <div 
            className="relative h-[700px] overflow-hidden cursor-pointer group"
            onClick={() => setActiveCategory('shoes')}
          >
            <img 
              src="https://static.zara.net/photos///contents/mkt/spots/ss24-north-man-shoes/subhome-xmedia-04//w/1920/IMAGE-landscape-fill-b8c3244e-2e53-4b95-8f65-7f1e2eea2bb4-default_0.jpg?ts=1705593339614" 
              alt="Shoes collection" 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-black bg-opacity-20 group-hover:bg-opacity-30 transition-opacity duration-300" />
            <div className="absolute bottom-0 left-0 w-full p-8 text-white">
              <h3 className="font-didot text-4xl mb-2">SHOES</h3>
              <p className="text-sm uppercase tracking-widest">Discover More</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}