import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ChevronLeft, ChevronRight, Heart, ShoppingBag, Plus, Check, X } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  price: string;
  image: string;
  description: string;
  sizes: string[];
  category: string;
}

interface ProductCarouselProps {
  products: Product[];
  onProductClick: (product: Product) => void;
  title?: string;
}

export default function ProductCarousel({ products, onProductClick, title = "New Arrivals" }: ProductCarouselProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [visibleProducts, setVisibleProducts] = useState<Set<number>>(new Set());
  const [selectedSizes, setSelectedSizes] = useState<Record<string, string>>({});
  const [wishlist, setWishlist] = useState<Set<string>>(new Set());
  const [cartStatus, setCartStatus] = useState<Record<string, 'idle' | 'loading' | 'success' | 'error'>>({});
  const [isQuickViewOpen, setIsQuickViewOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [isMobile, setIsMobile] = useState(false);
  const [touchStart, setTouchStart] = useState(0);
  const [touchEnd, setTouchEnd] = useState(0);
  const [progress, setProgress] = useState(0);
  
  const carouselRef = useRef<HTMLDivElement>(null);
  const carouselTrackRef = useRef<HTMLDivElement>(null);
  const autoScrollRef = useRef<NodeJS.Timeout | null>(null);
  const progressRef = useRef<NodeJS.Timeout | null>(null);
  const prefersReducedMotion = useRef(window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const productRefs = useRef<Map<string, HTMLDivElement>>(new Map());
  const observerRef = useRef<IntersectionObserver | null>(null);
  
  const totalSlides = Math.ceil(products.length / (isMobile ? 1 : 3));
  const slidesPerView = isMobile ? 1 : 3;
  const autoScrollDuration = 20000; // 20 seconds per complete cycle
  
  // Setup responsive behavior
  useEffect(() => {
    const handleResize = debounce(() => {
      setIsMobile(window.innerWidth < 768);
    }, 250);
    
    handleResize();
    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  
  // Setup Intersection Observer for lazy loading
  useEffect(() => {
    const observerCallback = (entries: IntersectionObserverEntry[]) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const productIndex = parseInt(entry.target.id.split('-')[1]);
          setVisibleProducts(prev => new Set(prev).add(productIndex));
        }
      });
    };
    
    observerRef.current = new IntersectionObserver(observerCallback, {
      root: null,
      rootMargin: '100px',
      threshold: 0.1
    });
    
    return () => {
      if (observerRef.current) {
        observerRef.current.disconnect();
      }
    };
  }, []);
  
  // Observe product elements
  useEffect(() => {
    if (observerRef.current) {
      productRefs.current.forEach((ref) => {
        if (ref) observerRef.current?.observe(ref);
      });
    }
    
    return () => {
      if (observerRef.current) {
        observerRef.current.disconnect();
      }
    };
  }, [products, isMobile]);
  
  // Auto-scroll functionality
  useEffect(() => {
    if (prefersReducedMotion.current || isPaused) {
      if (autoScrollRef.current) {
        clearInterval(autoScrollRef.current);
        autoScrollRef.current = null;
      }
      if (progressRef.current) {
        clearInterval(progressRef.current);
        progressRef.current = null;
      }
      return;
    }
    
    // Progress bar animation
    if (progressRef.current) {
      clearInterval(progressRef.current);
    }
    
    setProgress(0);
    const progressInterval = 50; // Update every 50ms for smooth animation
    const progressStep = (progressInterval / autoScrollDuration) * 100;
    
    progressRef.current = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + progressStep;
        return newProgress >= 100 ? 0 : newProgress;
      });
    }, progressInterval);
    
    // Auto-scroll
    if (autoScrollRef.current) {
      clearInterval(autoScrollRef.current);
    }
    
    autoScrollRef.current = setInterval(() => {
      setActiveIndex(prev => (prev + 1) % totalSlides);
    }, autoScrollDuration);
    
    return () => {
      if (autoScrollRef.current) {
        clearInterval(autoScrollRef.current);
      }
      if (progressRef.current) {
        clearInterval(progressRef.current);
      }
    };
  }, [isPaused, totalSlides, autoScrollDuration]);
  
  // Handle slide transition
  useEffect(() => {
    if (carouselTrackRef.current) {
      const offset = activeIndex * (100 / totalSlides);
      carouselTrackRef.current.style.transform = `translateX(-${offset}%)`;
    }
  }, [activeIndex, totalSlides]);
  
  const handlePrev = useCallback(() => {
    setActiveIndex(prev => (prev === 0 ? totalSlides - 1 : prev - 1));
    announceSlideChange('previous');
  }, [totalSlides]);
  
  const handleNext = useCallback(() => {
    setActiveIndex(prev => (prev + 1) % totalSlides);
    announceSlideChange('next');
  }, [totalSlides]);
  
  const goToSlide = useCallback((index: number) => {
    setActiveIndex(index);
    announceSlideChange(`${index + 1} of ${totalSlides}`);
  }, [totalSlides]);
  
  const handleAddToCart = useCallback((product: Product) => {
    if (!selectedSizes[product.id]) {
      alert('Please select a size');
      return;
    }
    
    setCartStatus(prev => ({ ...prev, [product.id]: 'loading' }));
    
    // Simulate API call
    setTimeout(() => {
      try {
        // Success simulation (95% success rate)
        if (Math.random() > 0.05) {
          setCartStatus(prev => ({ ...prev, [product.id]: 'success' }));
          // Reset after 2 seconds
          setTimeout(() => {
            setCartStatus(prev => ({ ...prev, [product.id]: 'idle' }));
          }, 2000);
        } else {
          // Error simulation
          setCartStatus(prev => ({ ...prev, [product.id]: 'error' }));
          // Reset after 2 seconds
          setTimeout(() => {
            setCartStatus(prev => ({ ...prev, [product.id]: 'idle' }));
          }, 2000);
        }
      } catch (error) {
        setCartStatus(prev => ({ ...prev, [product.id]: 'error' }));
      }
    }, 800);
  }, [selectedSizes]);
  
  const toggleWishlist = useCallback((productId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    setWishlist(prev => {
      const newWishlist = new Set(prev);
      if (newWishlist.has(productId)) {
        newWishlist.delete(productId);
      } else {
        newWishlist.add(productId);
      }
      return newWishlist;
    });
  }, []);
  
  const handleQuickView = useCallback((product: Product, event: React.MouseEvent) => {
    event.stopPropagation();
    setQuickViewProduct(product);
    setIsQuickViewOpen(true);
  }, []);
  
  const closeQuickView = useCallback(() => {
    setIsQuickViewOpen(false);
    setQuickViewProduct(null);
  }, []);
  
  const handleSizeChange = useCallback((productId: string, size: string) => {
    setSelectedSizes(prev => ({ ...prev, [productId]: size }));
  }, []);
  
  // Touch handlers for mobile swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX);
  };
  
  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };
  
  const handleTouchEnd = () => {
    if (touchStart - touchEnd > 100) {
      // Swipe left
      handleNext();
    }
    
    if (touchStart - touchEnd < -100) {
      // Swipe right
      handlePrev();
    }
  };
  
  // Accessibility announcement
  const announceSlideChange = (direction: string) => {
    const announcement = document.getElementById('carousel-announcement');
    if (announcement) {
      announcement.textContent = `Showing slide ${direction}`;
    }
  };
  
  // Utility function for debouncing
  function debounce(func: Function, wait: number) {
    let timeout: NodeJS.Timeout;
    return function executedFunction(...args: any[]) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }
  
  // Set ref for product elements
  const setProductRef = (id: string, element: HTMLDivElement | null) => {
    if (element) {
      productRefs.current.set(id, element);
    } else {
      productRefs.current.delete(id);
    }
  };
  
  // Render product cards
  const renderProductCards = () => {
    const cards = [];
    
    for (let i = 0; i < totalSlides; i++) {
      const startIdx = i * slidesPerView;
      const slideProducts = products.slice(startIdx, startIdx + slidesPerView);
      
      cards.push(
        <div key={`slide-${i}`} className="carousel-slide">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {slideProducts.map((product, idx) => {
              const productIndex = startIdx + idx;
              const isVisible = visibleProducts.has(productIndex);
              const isWishlisted = wishlist.has(product.id);
              const cartState = cartStatus[product.id] || 'idle';
              
              return (
                <div
                  key={product.id}
                  id={`product-${productIndex}`}
                  ref={(el) => setProductRef(`product-${productIndex}`, el)}
                  className="product-card group relative"
                  onClick={() => onProductClick(product)}
                  style={{
                    opacity: isVisible ? 1 : 0,
                    transform: `translateY(${isVisible ? '0' : '20px'})`,
                    transition: 'opacity 0.4s ease-in-out, transform 0.3s ease-out, box-shadow 0.3s ease-in-out'
                  }}
                >
                  <div className="aspect-w-3 aspect-h-4 overflow-hidden rounded-lg">
                    {isVisible ? (
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover object-center transition-transform duration-300 ease-out group-hover:scale-105"
                        loading="lazy"
                      />
                    ) : (
                      <div className="w-full h-full bg-gray-200 skeleton" />
                    )}
                    
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-opacity duration-300 ease-in-out" />
                    
                    {/* Wishlist button */}
                    <button
                      aria-label={isWishlisted ? "Remove from wishlist" : "Add to wishlist"}
                      onClick={(e) => toggleWishlist(product.id, e)}
                      className="absolute top-4 right-4 p-2 bg-white rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-black"
                    >
                      <Heart
                        size={20}
                        className={isWishlisted ? "fill-black text-black" : "text-gray-600"}
                      />
                    </button>
                    
                    {/* Quick view button */}
                    <button
                      aria-label="Quick view"
                      onClick={(e) => handleQuickView(product, e)}
                      className="absolute bottom-4 left-4 px-4 py-2 bg-white text-black text-sm font-medium rounded-md shadow-md opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-black"
                    >
                      Quick View
                    </button>
                  </div>
                  
                  <div className="mt-4 space-y-2 transform transition-all duration-300 ease-out group-hover:translate-y-[-8px]">
                    <h3 className="font-didot text-lg">{product.name}</h3>
                    <p className="text-sm text-gray-900">{product.price}</p>
                    
                    <div className="flex flex-col space-y-3">
                      <div className="relative">
                        <select
                          value={selectedSizes[product.id] || ''}
                          onChange={(e) => handleSizeChange(product.id, e.target.value)}
                          className="w-full py-2 pl-3 pr-10 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-black focus:border-black text-sm"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <option value="">Select Size</option>
                          {product.sizes.map(size => (
                            <option key={size} value={size}>{size}</option>
                          ))}
                        </select>
                      </div>
                      
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleAddToCart(product);
                        }}
                        disabled={cartState === 'loading'}
                        className={`w-full py-2 px-4 rounded-md text-sm font-medium focus:outline-none focus:ring-2 focus:ring-black transition-all duration-300 ease-in-out ${
                          cartState === 'success'
                            ? 'bg-green-600 text-white'
                            : cartState === 'error'
                            ? 'bg-red-600 text-white'
                            : 'bg-black text-white hover:bg-gray-900'
                        }`}
                      >
                        {cartState === 'loading' ? (
                          <span className="flex items-center justify-center">
                            <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Adding...
                          </span>
                        ) : cartState === 'success' ? (
                          <span className="flex items-center justify-center">
                            <Check size={16} className="mr-1" /> Added
                          </span>
                        ) : cartState === 'error' ? (
                          <span className="flex items-center justify-center">
                            <X size={16} className="mr-1" /> Failed
                          </span>
                        ) : (
                          <span className="flex items-center justify-center">
                            <ShoppingBag size={16} className="mr-1" /> Add to Cart
                          </span>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      );
    }
    
    return cards;
  };
  
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-didot mb-8 text-center">{title}</h2>
        
        <div
          ref={carouselRef}
          className="relative"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
          onFocus={() => setIsPaused(true)}
          onBlur={() => setIsPaused(false)}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          {/* Carousel track */}
          <div
            ref={carouselTrackRef}
            className="carousel-track"
            style={{
              display: 'flex',
              transition: prefersReducedMotion.current ? 'none' : 'transform 0.5s cubic-bezier(0.4, 0, 0.2, 1)',
              width: `${totalSlides * 100}%`
            }}
          >
            {renderProductCards()}
          </div>
          
          {/* Navigation buttons */}
          <button
            onClick={handlePrev}
            className="carousel-nav-button left-2"
            aria-label="Previous slide"
          >
            <ChevronLeft size={24} />
          </button>
          
          <button
            onClick={handleNext}
            className="carousel-nav-button right-2"
            aria-label="Next slide"
          >
            <ChevronRight size={24} />
          </button>
          
          {/* Progress indicators */}
          <div className="absolute bottom-0 left-0 right-0 flex justify-center space-x-2 mb-4">
            {Array.from({ length: totalSlides }).map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`h-1 rounded-full transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-black ${
                  index === activeIndex ? 'w-8 bg-black' : 'w-4 bg-gray-300'
                }`}
                aria-label={`Go to slide ${index + 1}`}
                aria-current={index === activeIndex ? 'true' : 'false'}
              />
            ))}
          </div>
          
          {/* Progress bar */}
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-200">
            <div
              className="h-full bg-black transition-all duration-100 ease-linear"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
        
        {/* Screen reader announcement */}
        <div
          id="carousel-announcement"
          className="sr-only"
          aria-live="polite"
          aria-atomic="true"
        />
        
        {/* Quick view modal */}
        {isQuickViewOpen && quickViewProduct && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
            <div className="bg-white max-w-4xl w-full mx-4 p-8 rounded-lg shadow-lg">
              <div className="flex justify-end mb-4">
                <button
                  onClick={closeQuickView}
                  className="text-gray-400 hover:text-black transition-colors"
                  aria-label="Close quick view"
                >
                  <X size={24} />
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="aspect-w-1 aspect-h-1 bg-gray-100 rounded-lg overflow-hidden">
                  <img
                    src={quickViewProduct.image}
                    alt={quickViewProduct.name}
                    className="w-full h-full object-cover object-center"
                  />
                </div>
                
                <div className="space-y-6">
                  <div>
                    <h1 className="text-2xl font-didot mb-2">{quickViewProduct.name}</h1>
                    <p className="text-xl text-gray-900 mb-4">{quickViewProduct.price}</p>
                    <p className="text-gray-600 font-helvetica">{quickViewProduct.description}</p>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Size
                    </label>
                    <div className="grid grid-cols-4 gap-2">
                      {quickViewProduct.sizes.map((size) => (
                        <button
                          key={size}
                          className={`py-2 text-center border transition-colors rounded-lg ${
                            selectedSizes[quickViewProduct.id] === size
                              ? 'border-black bg-black text-white'
                              : 'border-gray-300 hover:border-black'
                          }`}
                          onClick={() => handleSizeChange(quickViewProduct.id, size)}
                        >
                          {size}
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <button
                    onClick={() => handleAddToCart(quickViewProduct)}
                    className="w-full bg-black text-white py-3 hover:bg-gray-900 transition-colors font-bd-sans rounded-lg shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 ease-in-out"
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      
      <style jsx>{`
        .carousel-slide {
          width: ${100 / totalSlides}%;
          padding: 0 1rem;
        }
        
        .carousel-nav-button {
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
          width: 40px;
          height: 40px;
          border-radius: 50%;
          background-color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
          z-index: 10;
          opacity: 0;
          transition: opacity 0.3s ease-in-out;
        }
        
        .carousel-track:hover .carousel-nav-button,
        .carousel-track:focus-within .carousel-nav-button {
          opacity: 1;
        }
        
        .product-card {
          cursor: pointer;
          transition: transform 0.3s ease-out, box-shadow 0.3s ease-in-out;
        }
        
        .product-card:hover {
          transform: scale(1.05) rotate(2deg);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        @media (prefers-reduced-motion: reduce) {
          .carousel-track {
            transition: none !important;
          }
          
          .product-card:hover {
            transform: none;
          }
        }
        
        @media (max-width: 768px) {
          .carousel-nav-button {
            opacity: 1;
          }
        }
      `}</style>
    </section>
  );
}