import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { Package, MapPin, Tag, Shield, ChevronRight } from 'lucide-react';

interface Order {
  id: string;
  created_at: string;
  status: string;
  total: number;
  items: {
    name: string;
    quantity: number;
    size: string;
    price: number;
  }[];
}

interface Address {
  id: string;
  type: 'billing' | 'shipping';
  name: string;
  street: string;
  city: string;
  state: string;
  postal_code: string;
  country: string;
  is_default: boolean;
}

interface Coupon {
  code: string;
  discount: number;
  expires_at: string;
  used: boolean;
}

export default function Account() {
  const [activeTab, setActiveTab] = useState<'orders' | 'addresses' | 'coupons' | 'security'>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [userEmail, setUserEmail] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const supabase = createClient(
          import.meta.env.VITE_SUPABASE_URL,
          import.meta.env.VITE_SUPABASE_ANON_KEY
        );

        const { data: { user }, error } = await supabase.auth.getUser();
        
        if (error) throw error;
        
        if (user) {
          setUserEmail(user.email || '');
          
          // Fetch orders
          const { data: ordersData } = await supabase
            .from('orders')
            .select('*')
            .eq('user_id', user.id)
            .order('created_at', { ascending: false });
            
          if (ordersData) setOrders(ordersData);

          // Fetch addresses
          const { data: addressesData } = await supabase
            .from('addresses')
            .select('*')
            .eq('user_id', user.id);
            
          if (addressesData) setAddresses(addressesData);

          // Fetch coupons
          const { data: couponsData } = await supabase
            .from('coupons')
            .select('*')
            .eq('user_id', user.id);
            
          if (couponsData) setCoupons(couponsData);
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, []);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-sm">
          {/* Account Header */}
          <div className="border-b border-gray-200 px-8 py-6">
            <h1 className="text-2xl font-didot">My Account</h1>
            <p className="text-sm text-gray-600 mt-1">{userEmail}</p>
          </div>

          {/* Navigation Tabs */}
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px px-8">
              <button
                onClick={() => setActiveTab('orders')}
                className={`flex items-center py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'orders'
                    ? 'border-black text-black'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Package size={18} className="mr-2" />
                Orders
              </button>
              <button
                onClick={() => setActiveTab('addresses')}
                className={`flex items-center ml-8 py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'addresses'
                    ? 'border-black text-black'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <MapPin size={18} className="mr-2" />
                Addresses
              </button>
              <button
                onClick={() => setActiveTab('coupons')}
                className={`flex items-center ml-8 py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'coupons'
                    ? 'border-black text-black'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Tag size={18} className="mr-2" />
                Coupons
              </button>
              <button
                onClick={() => setActiveTab('security')}
                className={`flex items-center ml-8 py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'security'
                    ? 'border-black text-black'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Shield size={18} className="mr-2" />
                Security
              </button>
            </nav>
          </div>

          {/* Content Sections */}
          <div className="px-8 py-6">
            {/* Orders */}
            {activeTab === 'orders' && (
              <div className="space-y-6">
                {orders.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No orders yet</p>
                ) : (
                  orders.map((order) => (
                    <div key={order.id} className="border rounded-lg p-6 space-y-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-sm text-gray-600">Order #{order.id}</p>
                          <p className="text-sm text-gray-600">{formatDate(order.created_at)}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{formatCurrency(order.total)}</p>
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            order.status === 'delivered'
                              ? 'bg-green-100 text-green-800'
                              : order.status === 'processing'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-gray-100 text-gray-800'
                          }`}>
                            {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                          </span>
                        </div>
                      </div>
                      <div className="border-t pt-4">
                        {order.items.map((item, index) => (
                          <div key={index} className="flex justify-between items-center py-2">
                            <div>
                              <p className="font-medium">{item.name}</p>
                              <p className="text-sm text-gray-600">Size: {item.size}</p>
                            </div>
                            <div className="text-right">
                              <p>{formatCurrency(item.price)}</p>
                              <p className="text-sm text-gray-600">Qty: {item.quantity}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Addresses */}
            {activeTab === 'addresses' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-lg font-medium">Saved Addresses</h2>
                  <button className="bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-900 transition-colors">
                    Add New Address
                  </button>
                </div>
                {addresses.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No addresses saved</p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {addresses.map((address) => (
                      <div key={address.id} className="border rounded-lg p-6 relative">
                        {address.is_default && (
                          <span className="absolute top-4 right-4 bg-black text-white text-xs px-2 py-1 rounded">
                            Default
                          </span>
                        )}
                        <p className="font-medium">{address.name}</p>
                        <p className="text-sm text-gray-600 mt-2">{address.street}</p>
                        <p className="text-sm text-gray-600">
                          {address.city}, {address.state} {address.postal_code}
                        </p>
                        <p className="text-sm text-gray-600">{address.country}</p>
                        <div className="mt-4 flex space-x-4">
                          <button className="text-sm text-gray-600 hover:text-black">Edit</button>
                          <button className="text-sm text-red-600 hover:text-red-800">Delete</button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Coupons */}
            {activeTab === 'coupons' && (
              <div className="space-y-6">
                {coupons.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No coupons available</p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {coupons.map((coupon) => (
                      <div key={coupon.code} className="border rounded-lg p-6">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-medium text-lg">{coupon.code}</p>
                            <p className="text-sm text-gray-600">
                              {coupon.discount}% off your order
                            </p>
                          </div>
                          {coupon.used ? (
                            <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">
                              Used
                            </span>
                          ) : (
                            <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                              Active
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 mt-4">
                          Expires: {formatDate(coupon.expires_at)}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Security */}
            {activeTab === 'security' && (
              <div className="space-y-6">
                <div className="border rounded-lg divide-y">
                  <div className="p-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-medium">Email Address</h3>
                        <p className="text-sm text-gray-600 mt-1">{userEmail}</p>
                      </div>
                      <button className="text-sm text-gray-600 hover:text-black">
                        Change
                      </button>
                    </div>
                  </div>
                  <div className="p-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-medium">Password</h3>
                        <p className="text-sm text-gray-600 mt-1">Last changed 3 months ago</p>
                      </div>
                      <button className="text-sm text-gray-600 hover:text-black">
                        Update
                      </button>
                    </div>
                  </div>
                  <div className="p-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-medium">Two-Factor Authentication</h3>
                        <p className="text-sm text-gray-600 mt-1">Not enabled</p>
                      </div>
                      <button className="text-sm text-gray-600 hover:text-black">
                        Enable
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}