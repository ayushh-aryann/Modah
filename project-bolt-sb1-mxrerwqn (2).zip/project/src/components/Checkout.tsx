import React, { useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import { 
  CreditCard, 
  Smartphone, 
  Wallet, 
  Building2,
  ChevronRight,
  Check,
  AlertCircle,
  Loader2
} from 'lucide-react';

interface PaymentMethod {
  id: string;
  type: 'card' | 'upi' | 'wallet' | 'netbanking';
  name: string;
  icon: React.ReactNode;
}

interface CheckoutProps {
  cartItems: any[];
  onClose: () => void;
  onSuccess: () => void;
}

const paymentMethods: PaymentMethod[] = [
  { id: 'card', type: 'card', name: 'Credit/Debit Card', icon: <CreditCard size={20} /> },
  { id: 'upi', type: 'upi', name: 'UPI', icon: <Smartphone size={20} /> },
  { id: 'wallet', type: 'wallet', name: 'Digital Wallet', icon: <Wallet size={20} /> },
  { id: 'netbanking', type: 'netbanking', name: 'Net Banking', icon: <Building2 size={20} /> }
];

const banks = [
  'State Bank of India',
  'HDFC Bank',
  'ICICI Bank',
  'Axis Bank',
  'Kotak Mahindra Bank',
  'Yes Bank'
];

const wallets = [
  'Paytm',
  'Amazon Pay',
  'PhonePe',
  'Google Pay',
  'MobiKwik'
];

const upiApps = [
  'PhonePe',
  'Google Pay',
  'Paytm',
  'BHIM'
];

export default function Checkout({ cartItems, onClose, onSuccess }: CheckoutProps) {
  const [selectedMethod, setSelectedMethod] = useState<string>('');
  const [selectedOption, setSelectedOption] = useState<string>('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCvv] = useState('');
  const [upiId, setUpiId] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const subtotal = cartItems.reduce((sum, item) => {
    const price = parseFloat(item.price.replace('₹', '').replace(',', ''));
    return sum + price * item.quantity;
  }, 0);

  const shipping = 99;
  const tax = subtotal * 0.18; // 18% GST
  const total = subtotal + shipping + tax;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  };

  const validateCard = () => {
    if (cardNumber.length !== 16) return 'Invalid card number';
    if (cardName.length < 3) return 'Invalid name';
    if (cardExpiry.length !== 5) return 'Invalid expiry date';
    if (cardCvv.length !== 3) return 'Invalid CVV';
    return '';
  };

  const validateUpi = () => {
    const upiRegex = /^[\w\.\-]+@[\w\-]+$/;
    if (!upiRegex.test(upiId)) return 'Invalid UPI ID';
    return '';
  };

  const handlePayment = async () => {
    setError('');
    setLoading(true);

    let validationError = '';
    if (selectedMethod === 'card') {
      validationError = validateCard();
    } else if (selectedMethod === 'upi') {
      validationError = validateUpi();
    } else if (!selectedOption) {
      validationError = 'Please select a payment option';
    }

    if (validationError) {
      setError(validationError);
      setLoading(false);
      return;
    }

    try {
      const supabase = createClient(
        import.meta.env.VITE_SUPABASE_URL,
        import.meta.env.VITE_SUPABASE_ANON_KEY
      );

      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');

      // Create order in database
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert([
          {
            user_id: user.id,
            items: cartItems,
            total: total,
            payment_method: selectedMethod,
            status: 'processing'
          }
        ])
        .select()
        .single();

      if (orderError) throw orderError;

      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Update order status
      const { error: updateError } = await supabase
        .from('orders')
        .update({ status: 'confirmed' })
        .eq('id', order.id);

      if (updateError) throw updateError;

      setSuccess(true);
      setTimeout(() => {
        onSuccess();
      }, 2000);

    } catch (err) {
      console.error('Payment error:', err);
      setError('Payment failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const formatCardNumber = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    return numbers.slice(0, 16);
  };

  const formatExpiry = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length >= 2) {
      return `${numbers.slice(0, 2)}/${numbers.slice(2, 4)}`;
    }
    return numbers;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white w-full max-w-4xl mx-4 rounded-lg shadow-xl">
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-didot">Checkout</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6">
          <div>
            <h3 className="text-lg font-medium mb-4">Payment Method</h3>
            
            <div className="space-y-4">
              {paymentMethods.map((method) => (
                <button
                  key={method.id}
                  onClick={() => {
                    setSelectedMethod(method.id);
                    setSelectedOption('');
                    setError('');
                  }}
                  className={`w-full flex items-center justify-between p-4 rounded-lg border ${
                    selectedMethod === method.id
                      ? 'border-black bg-gray-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center">
                    {method.icon}
                    <span className="ml-3">{method.name}</span>
                  </div>
                  <ChevronRight size={20} className="text-gray-400" />
                </button>
              ))}
            </div>

            {selectedMethod === 'card' && (
              <div className="mt-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Card Number
                  </label>
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                    placeholder="1234 5678 9012 3456"
                    className="w-full px-4 py-2 border rounded-lg focus:ring-black focus:border-black"
                    maxLength={16}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Name on Card
                  </label>
                  <input
                    type="text"
                    value={cardName}
                    onChange={(e) => setCardName(e.target.value)}
                    placeholder="John Doe"
                    className="w-full px-4 py-2 border rounded-lg focus:ring-black focus:border-black"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Expiry Date
                    </label>
                    <input
                      type="text"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(formatExpiry(e.target.value))}
                      placeholder="MM/YY"
                      className="w-full px-4 py-2 border rounded-lg focus:ring-black focus:border-black"
                      maxLength={5}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      CVV
                    </label>
                    <input
                      type="password"
                      value={cardCvv}
                      onChange={(e) => setCvv(e.target.value.replace(/\D/g, ''))}
                      placeholder="123"
                      className="w-full px-4 py-2 border rounded-lg focus:ring-black focus:border-black"
                      maxLength={3}
                    />
                  </div>
                </div>
              </div>
            )}

            {selectedMethod === 'upi' && (
              <div className="mt-6 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  {upiApps.map((app) => (
                    <button
                      key={app}
                      onClick={() => setSelectedOption(app)}
                      className={`p-4 border rounded-lg text-center ${
                        selectedOption === app
                          ? 'border-black bg-gray-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      {app}
                    </button>
                  ))}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    UPI ID
                  </label>
                  <input
                    type="text"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    placeholder="username@upi"
                    className="w-full px-4 py-2 border rounded-lg focus:ring-black focus:border-black"
                  />
                </div>
              </div>
            )}

            {selectedMethod === 'wallet' && (
              <div className="mt-6">
                <div className="grid grid-cols-2 gap-4">
                  {wallets.map((wallet) => (
                    <button
                      key={wallet}
                      onClick={() => setSelectedOption(wallet)}
                      className={`p-4 border rounded-lg text-center ${
                        selectedOption === wallet
                          ? 'border-black bg-gray-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      {wallet}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {selectedMethod === 'netbanking' && (
              <div className="mt-6">
                <div className="grid grid-cols-2 gap-4">
                  {banks.map((bank) => (
                    <button
                      key={bank}
                      onClick={() => setSelectedOption(bank)}
                      className={`p-4 border rounded-lg text-center ${
                        selectedOption === bank
                          ? 'border-black bg-gray-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      {bank}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div>
            <h3 className="text-lg font-medium mb-4">Order Summary</h3>
            
            <div className="bg-gray-50 rounded-lg p-6">
              <div className="space-y-4">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex justify-between">
                    <div>
                      <p className="font-medium">{item.name}</p>
                      <p className="text-sm text-gray-600">
                        Size: {item.selectedSize} × {item.quantity}
                      </p>
                    </div>
                    <p>{item.price}</p>
                  </div>
                ))}
              </div>

              <div className="border-t mt-6 pt-6 space-y-3">
                <div className="flex justify-between text-sm">
                  <span>Subtotal</span>
                  <span>{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Shipping</span>
                  <span>{formatCurrency(shipping)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Tax (18% GST)</span>
                  <span>{formatCurrency(tax)}</span>
                </div>
                <div className="flex justify-between font-medium text-lg pt-3 border-t">
                  <span>Total</span>
                  <span>{formatCurrency(total)}</span>
                </div>
              </div>
            </div>

            {error && (
              <div className="mt-4 p-4 bg-red-50 rounded-lg flex items-center text-red-800">
                <AlertCircle size={20} className="mr-2" />
                {error}
              </div>
            )}

            {success && (
              <div className="mt-4  p-4 bg-green-50 rounded-lg flex items-center text-green-800">
                <Check size={20} className="mr-2" />
                Payment successful! Redirecting...
              </div>
            )}

            <button
              onClick={handlePayment}
              disabled={!selectedMethod || loading || success}
              className={`w-full mt-6 py-3 rounded-lg text-white font-medium ${
                loading || !selectedMethod || success
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-black hover:bg-gray-900'
              }`}
            >
              {loading ? (
                <span className="flex items-center justify-center">
                  <Loader2 size={20} className="animate-spin mr-2" />
                  Processing...
                </span>
              ) : success ? (
                <span className="flex items-center justify-center">
                  <Check size={20} className="mr-2" />
                  Payment Complete
                </span>
              ) : (
                `Pay ${formatCurrency(total)}`
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}